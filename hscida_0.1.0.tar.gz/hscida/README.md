# hsci-da

Installable Python package for HSCI data access utilities built on DuckDB and Narwhals.
